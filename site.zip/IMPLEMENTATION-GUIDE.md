# Decanta.ai — Week 1 SEO Implementation Checklist

## Files in this package
1. `robots.txt`           → Upload to https://decanta.ai/robots.txt
2. `sitemap.xml`          → Upload to https://decanta.ai/sitemap.xml
3. `head-replacement.html` → Replace your entire <head>...</head> with this content
4. `faq-section.html`     → Paste into index.html just before your </footer> tag
5. `image-alt-fixes.html` → Find/replace each img tag as documented

---

## Step 1 — Upload the files (30 mins)

1. Upload `robots.txt` to your site root (same level as index.html)
2. Upload `sitemap.xml` to your site root
3. Verify both are accessible:
   - Visit https://decanta.ai/robots.txt in your browser → should see plain text
   - Visit https://decanta.ai/sitemap.xml in your browser → should see XML

---

## Step 2 — Update index.html (45 mins)

1. Open index.html in your editor
2. Find your entire `<head>...</head>` block
3. Replace it completely with the contents of `head-replacement.html`
   - Keep your existing <link> tags for CSS stylesheets at the bottom of <head>
   - Keep any existing <script> tags for your app JS at the bottom of <body>
4. Paste the contents of `faq-section.html` just before your closing `</footer>` tag
5. Fix each image alt tag as documented in `image-alt-fixes.html`

⚠️  IMPORTANT: Update these placeholder values in head-replacement.html:
   - `https://decanta.ai/images/og-image.png` → create a 1200×630px branded image for social sharing
   - `@decantaai` → your actual Twitter/X handle if different
   - `https://www.linkedin.com/company/decanta-ai` → your actual LinkedIn URL

---

## Step 3 — Google Search Console (30 mins)

1. Go to https://search.google.com/search-console
2. Click "Add property" → choose "Domain" → enter `decanta.ai`
3. Verify ownership via one of:
   - DNS TXT record (recommended — ask your DNS provider/registrar to add it)
   - HTML file upload (download the file Google gives you, upload to site root)
4. Once verified:
   a. Go to Sitemaps → enter `sitemap.xml` → click Submit
   b. Go to URL Inspection → enter `https://decanta.ai/` → click "Request indexing"
5. Repeat URL inspection request for any other pages you have live

---

## Step 4 — Google Analytics 4 (30 mins)

1. Go to https://analytics.google.com
2. Create a new GA4 property for decanta.ai
3. Copy the Measurement ID (format: G-XXXXXXXXXX)
4. Add this to your <head> (replace G-XXXXXXXXXX with your real ID):

```html
<!-- Google Analytics 4 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX');
</script>
```

---

## Step 5 — Free directory listings (1–2 hours)

Do these in order — each creates a backlink to decanta.ai:

| Platform     | URL                              | Notes                              |
|--------------|----------------------------------|------------------------------------|
| Product Hunt | producthunt.com/posts/new        | Best day: Tuesday. Tag: Wine, AI   |
| Crunchbase   | crunchbase.com/add-new           | Free company profile               |
| LinkedIn Co. | linkedin.com/company/setup/new   | Add decanta.ai as website          |
| G2           | g2.com/products/new              | Category: Restaurant Management    |
| Capterra     | capterra.com/vendors/sign-up     | Category: Restaurant Software      |
| AlternativeTo| alternativeto.net/suggest        | List as alternative to Vivino      |
| There's An AI| theresanai.com/submit            | Free AI tool directory             |
| AI Tools Dir | aitoolsdirectory.com/submit      | Free listing                       |
| Futurepedia  | futurepedia.io/submit-tool       | Free AI directory                  |

---

## Step 6 — Verify everything worked (after 48 hours)

Search Google for:
- `site:decanta.ai` → should now return results (may take 1–2 weeks)
- `decanta.ai wine` → check if you appear
- `decanta ai sommelier` → monitor position over time

Check Search Console for:
- Coverage report → pages indexed
- Sitemaps → status "Success"
- Core Web Vitals → identify any speed issues

---

## What to build next (Month 1)

Once the above is done, the highest-ROI next steps are:

1. **Convert to multi-page** — split the single-page site into separate URLs:
   - /for-restaurants
   - /for-wine-lovers
   - /features/ai-sommelier
   - /features/cellar-management
   - /pricing
   Each new page = more keywords you can rank for.

2. **Start a blog** — target 2–4 posts/month. First 4 articles to write:
   - "Best Wine Cellar Management Apps in 2026 (Honest Comparison)"
   - "How AI Sommelier Software Increases Restaurant Wine Revenue"
   - "How to Digitise Your Wine Cellar in 30 Minutes"
   - "Premium Wine By the Glass: How Bottle Sharing Works"

3. **Get your first 10 backlinks** — email wine bloggers who write "best wine apps"
   roundups and ask to be included.
